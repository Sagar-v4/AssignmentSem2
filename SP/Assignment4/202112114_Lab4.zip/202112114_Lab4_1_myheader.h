int myfact(int);
int mypow(int, int);
