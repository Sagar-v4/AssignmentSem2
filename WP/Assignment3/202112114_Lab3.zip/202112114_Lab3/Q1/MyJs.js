var displayData = document.getElementById("data");
var fname;
var lname;
function firstName() {
    fname = document.getElementById("fn");
    writeData();
}
function lastName() {
    lname = document.getElementById("ln");
    writeData();
}
function writeData() {
    displayData.innerHTML = fname.value + " " + lname.value;
}

var align1 = document.getElementById("align1");
align1.addEventListener("change", myFunction);
function myFunction() {
    document.getElementById("details").style.textAlign = align1.value;
}

var slide = document.getElementById("slide");
function fontSize() {
    document.getElementById("details").style.fontSize = (slide.value + 'px');

}
